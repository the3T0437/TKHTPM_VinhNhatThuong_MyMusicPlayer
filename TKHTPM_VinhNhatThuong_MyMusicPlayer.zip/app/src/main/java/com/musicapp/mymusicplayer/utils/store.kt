package com.musicapp.mymusicplayer.utils

import androidx.media3.session.MediaController

object store {
    var mediaController: MediaController? = null
}